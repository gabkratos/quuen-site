let txt1 = document.getElementById("email");
let txt2 = document.getElementById("Senha");

function change(){
    const infos = [0,0];
    infos[0] = txt1.value;
    infos[1] = txt2.value;
       console.log(infos);
}